package com.universal.carlauncher.core.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "car_launcher_settings")

enum class SpeedometerStyle {
    DIGITAL_AND_CIRCULAR,
    DIGITAL_ONLY,
    CIRCULAR_ONLY
}

enum class WidgetSizeScale(val labelAr: String, val scaleMultiplier: Float) {
    SMALL("صغير", 0.88f),
    MEDIUM("متوسط", 1.0f),
    LARGE("كبير", 1.15f)
}

enum class DashboardWidgetId(val titleAr: String) {
    COMPASS("بوصلة الاتجاهات"),
    TRIP_SUMMARY("المسافة ومدة الرحلة"),
    PRAYER_TIMES("مواقيت الصلاة والصلاة القادمة"),
    WEATHER_TEMP("الطقس ودرجة الحرارة الخارجية"),
    MINI_MUSIC("مشغل الموسيقى المصغر"),
    APP_SHORTCUTS("اختصارات التطبيقات السريعة")
}

data class PersistedLauncherSettings(
    val neonAccentEnabled: Boolean = true,
    val speedometerStyle: SpeedometerStyle = SpeedometerStyle.DIGITAL_AND_CIRCULAR,
    val autoStartOnBoot: Boolean = true,
    val userUiScaleMultiplier: Float = 1.0f,
    val visibleWidgets: Set<DashboardWidgetId> = DashboardWidgetId.entries.toSet(),
    val widgetOrder: List<DashboardWidgetId> = DashboardWidgetId.entries,
    val widgetSizeScale: WidgetSizeScale = WidgetSizeScale.MEDIUM
)

class LauncherPreferences(private val context: Context) {
    private object Keys {
        val NEON_ENABLED = booleanPreferencesKey("neon_enabled")
        val SPEEDOMETER_STYLE = stringPreferencesKey("speedometer_style")
        val AUTO_START_ON_BOOT = booleanPreferencesKey("auto_start_on_boot")
        val USER_UI_SCALE = floatPreferencesKey("user_ui_scale")
        val VISIBLE_WIDGETS = stringPreferencesKey("visible_widgets")
        val WIDGET_ORDER = stringPreferencesKey("widget_order")
        val WIDGET_SIZE = stringPreferencesKey("widget_size")
    }

    val settingsFlow: Flow<PersistedLauncherSettings> = context.dataStore.data.map { prefs ->
        val styleName = prefs[Keys.SPEEDOMETER_STYLE] ?: SpeedometerStyle.DIGITAL_AND_CIRCULAR.name
        val style = runCatching { SpeedometerStyle.valueOf(styleName) }
            .getOrDefault(SpeedometerStyle.DIGITAL_AND_CIRCULAR)

        val sizeName = prefs[Keys.WIDGET_SIZE] ?: WidgetSizeScale.MEDIUM.name
        val widgetSize = runCatching { WidgetSizeScale.valueOf(sizeName) }
            .getOrDefault(WidgetSizeScale.MEDIUM)

        val visibleRaw = prefs[Keys.VISIBLE_WIDGETS]
        val visibleSet = if (visibleRaw == null) {
            DashboardWidgetId.entries.toSet()
        } else if (visibleRaw.isBlank()) {
            emptySet()
        } else {
            visibleRaw.split(",")
                .mapNotNull { runCatching { DashboardWidgetId.valueOf(it) }.getOrNull() }
                .toSet()
        }

        val orderRaw = prefs[Keys.WIDGET_ORDER]
        val parsedOrder = orderRaw?.split(",")
            ?.mapNotNull { runCatching { DashboardWidgetId.valueOf(it) }.getOrNull() }
            .orEmpty()
        val finalOrder = (parsedOrder + DashboardWidgetId.entries).distinct()

        PersistedLauncherSettings(
            neonAccentEnabled = prefs[Keys.NEON_ENABLED] ?: true,
            speedometerStyle = style,
            autoStartOnBoot = prefs[Keys.AUTO_START_ON_BOOT] ?: true,
            userUiScaleMultiplier = prefs[Keys.USER_UI_SCALE] ?: 1.0f,
            visibleWidgets = visibleSet,
            widgetOrder = finalOrder,
            widgetSizeScale = widgetSize
        )
    }

    suspend fun setNeonEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.NEON_ENABLED] = enabled }
    }

    suspend fun setSpeedometerStyle(style: SpeedometerStyle) {
        context.dataStore.edit { it[Keys.SPEEDOMETER_STYLE] = style.name }
    }

    suspend fun setWidgetSizeScale(scale: WidgetSizeScale) {
        context.dataStore.edit { it[Keys.WIDGET_SIZE] = scale.name }
    }

    suspend fun toggleWidgetVisibility(widgetId: DashboardWidgetId) {
        context.dataStore.edit { prefs ->
            val currentRaw = prefs[Keys.VISIBLE_WIDGETS]
            val currentSet = if (currentRaw == null) {
                DashboardWidgetId.entries.toMutableSet()
            } else {
                currentRaw.split(",")
                    .mapNotNull { runCatching { DashboardWidgetId.valueOf(it) }.getOrNull() }
                    .toMutableSet()
            }
            if (currentSet.contains(widgetId)) currentSet.remove(widgetId) else currentSet.add(widgetId)
            prefs[Keys.VISIBLE_WIDGETS] = currentSet.joinToString(",") { it.name }
        }
    }

    suspend fun moveWidgetOrder(widgetId: DashboardWidgetId, moveEarlier: Boolean) {
        context.dataStore.edit { prefs ->
            val currentRaw = prefs[Keys.WIDGET_ORDER]
            val currentList = (
                currentRaw?.split(",")
                    ?.mapNotNull { runCatching { DashboardWidgetId.valueOf(it) }.getOrNull() }
                    .orEmpty() + DashboardWidgetId.entries
                ).distinct().toMutableList()

            val index = currentList.indexOf(widgetId)
            if (index != -1) {
                val targetIndex = if (moveEarlier) index - 1 else index + 1
                if (targetIndex in currentList.indices) {
                    val temp = currentList[targetIndex]
                    currentList[targetIndex] = currentList[index]
                    currentList[index] = temp
                    prefs[Keys.WIDGET_ORDER] = currentList.joinToString(",") { it.name }
                }
            }
        }
    }
}
