package com.universal.carlauncher.feature.dashboard

import android.graphics.drawable.Drawable
import com.universal.carlauncher.core.datastore.DashboardWidgetId
import com.universal.carlauncher.core.datastore.SpeedometerStyle
import com.universal.carlauncher.core.datastore.WidgetSizeScale
import com.universal.carlauncher.core.hardware.BluetoothHardwareState
import com.universal.carlauncher.core.hardware.GpsHardwareState
import com.universal.carlauncher.core.hardware.NetworkConnectionState

data class InstalledAppShortcut(
    val label: String,
    val packageName: String,
    val icon: Drawable?
)

data class DashboardUiState(
    val timeFormatted: String = "00:00",
    val secondsFormatted: String = "00",
    val amPmArabic: String = "ص",
    val dayNameArabic: String = "",
    val gregorianDateArabic: String = "",
    val hijriDateArabic: String = "",
    val currentSpeedKmh: Int? = null,
    val maxSpeedKmh: Int = 0,
    val bearingDegrees: Int? = null,
    val speedStatusNote: String = "بانتظار إشارة GPS الموثوقة",
    val gpsState: GpsHardwareState = GpsHardwareState.READY_STANDBY,
    val bluetoothState: BluetoothHardwareState = BluetoothHardwareState.OFF,
    val networkState: NetworkConnectionState = NetworkConnectionState.OFFLINE,
    val hasAmbientTempSensor: Boolean = false,
    val hasCompassSensor: Boolean = false,
    val tripDurationFormatted: String = "00:00:00",
    val distanceKmFormatted: String = "0.00 كم",
    val tasbeehCount: Int = 0,
    val neonEnabled: Boolean = true,
    val speedometerStyle: SpeedometerStyle = SpeedometerStyle.DIGITAL_AND_CIRCULAR,
    val widgetSizeScale: WidgetSizeScale = WidgetSizeScale.MEDIUM,
    val visibleWidgets: Set<DashboardWidgetId> = DashboardWidgetId.entries.toSet(),
    val orderedWidgets: List<DashboardWidgetId> = DashboardWidgetId.entries,
    val isCustomizationSheetOpen: Boolean = false,
    val isDefaultLauncher: Boolean = false,
    val appShortcuts: List<InstalledAppShortcut> = emptyList()
)
