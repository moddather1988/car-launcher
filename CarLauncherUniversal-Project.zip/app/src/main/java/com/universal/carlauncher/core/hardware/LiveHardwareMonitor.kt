package com.universal.carlauncher.core.hardware

import android.Manifest
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorManager
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.core.content.ContextCompat

enum class GpsHardwareState(val statusLabelAr: String) {
    UNSUPPORTED("غير مدعوم بالجهاز"),
    PERMISSION_REQUIRED("اضغط لتفعيل صلاحية GPS"),
    DISABLED("GPS مغلق"),
    READY_STANDBY("GPS متصل")
}

enum class BluetoothHardwareState(val statusLabelAr: String) {
    UNSUPPORTED("غير مدعوم"),
    OFF("البلوتوث مغلق"),
    ON_READY("البلوتوث مفعل")
}

enum class NetworkConnectionState(val statusLabelAr: String) {
    OFFLINE("Offline جاهز"),
    WIFI_CONNECTED("متصل Wi-Fi"),
    CELLULAR_CONNECTED("متصل بيانات")
}

data class HardwareSnapshot(
    val gpsState: GpsHardwareState,
    val bluetoothState: BluetoothHardwareState,
    val networkState: NetworkConnectionState,
    val hasAmbientTempSensor: Boolean,
    val hasCompassSensor: Boolean
)

class LiveHardwareMonitor(private val context: Context) {
    fun captureSnapshot(): HardwareSnapshot {
        val pm = context.packageManager
        val hasGpsFeature = pm.hasSystemFeature(PackageManager.FEATURE_LOCATION_GPS)
        val hasLocationPerm = ContextCompat.checkSelfPermission(
            context, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(
            context, Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        val isGpsProviderEnabled = runCatching {
            locationManager?.isProviderEnabled(LocationManager.GPS_PROVIDER) == true
        }.getOrDefault(false)

        val gpsState = when {
            !hasGpsFeature -> GpsHardwareState.UNSUPPORTED
            !hasLocationPerm -> GpsHardwareState.PERMISSION_REQUIRED
            !isGpsProviderEnabled -> GpsHardwareState.DISABLED
            else -> GpsHardwareState.READY_STANDBY
        }

        val hasBtFeature = pm.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH)
        val btManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val btAdapter = btManager?.adapter
        val btState = when {
            !hasBtFeature || btAdapter == null -> BluetoothHardwareState.UNSUPPORTED
            btAdapter.isEnabled -> BluetoothHardwareState.ON_READY
            else -> BluetoothHardwareState.OFF
        }

        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val activeNetwork = connectivityManager?.activeNetwork
        val capabilities = connectivityManager?.getNetworkCapabilities(activeNetwork)
        val netState = when {
            capabilities == null -> NetworkConnectionState.OFFLINE
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> NetworkConnectionState.WIFI_CONNECTED
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> NetworkConnectionState.CELLULAR_CONNECTED
            else -> NetworkConnectionState.OFFLINE
        }

        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val hasTempSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE) != null
        val hasMagnetometer = sensorManager?.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD) != null

        return HardwareSnapshot(
            gpsState = gpsState,
            bluetoothState = btState,
            networkState = netState,
            hasAmbientTempSensor = hasTempSensor,
            hasCompassSensor = hasMagnetometer
        )
    }
}
