package com.universal.carlauncher.feature.dashboard

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.universal.carlauncher.core.adaptive.AutomotiveWindowInfo
import com.universal.carlauncher.core.adaptive.ScreenOrientationMode
import com.universal.carlauncher.core.datastore.DashboardWidgetId
import com.universal.carlauncher.core.datastore.SpeedometerStyle
import com.universal.carlauncher.core.datastore.WidgetSizeScale
import com.universal.carlauncher.core.hardware.BluetoothHardwareState
import com.universal.carlauncher.core.hardware.GpsHardwareState
import com.universal.carlauncher.core.hardware.NetworkConnectionState
import com.universal.carlauncher.core.theme.AutomotiveColors
import com.universal.carlauncher.feature.dashboard.components.DashboardCustomizationPanel
import com.universal.carlauncher.feature.dashboard.components.DashboardWidgetCard
import com.universal.carlauncher.feature.dashboard.components.SpeedometerCockpitCard

@Composable
fun DashboardScreen(
    state: DashboardUiState,
    windowInfo: AutomotiveWindowInfo,
    onRequestLocationPerm: () -> Unit,
    onIncrementTasbeeh: () -> Unit,
    onToggleCustomization: () -> Unit,
    onToggleNeon: (Boolean) -> Unit,
    onSelectSpeedometerStyle: (SpeedometerStyle) -> Unit,
    onSelectWidgetSize: (WidgetSizeScale) -> Unit,
    onToggleWidgetVisibility: (DashboardWidgetId) -> Unit,
    onMoveWidget: (DashboardWidgetId, Boolean) -> Unit
) {
    val context = LocalContext.current
    val openSystemSetting: (String) -> Unit = { action ->
        runCatching {
            context.startActivity(Intent(action).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
        }
    }

    val activeWidgets = state.orderedWidgets.filter { state.visibleWidgets.contains(it) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        AutomotiveColors.DeepObsidian,
                        AutomotiveColors.CockpitSurface,
                        AutomotiveColors.DeepObsidian
                    )
                )
            )
            .padding(windowInfo.contentPadding)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(windowInfo.contentPadding)
        ) {
            CockpitTopStatusBar(
                state = state,
                windowInfo = windowInfo,
                onRequestLocationPerm = onRequestLocationPerm,
                onToggleCustomization = onToggleCustomization,
                onOpenSystemSetting = openSystemSetting
            )

            if (state.isCustomizationSheetOpen) {
                DashboardCustomizationPanel(
                    state = state,
                    onToggleNeon = onToggleNeon,
                    onSelectSpeedometerStyle = onSelectSpeedometerStyle,
                    onSelectWidgetSize = onSelectWidgetSize,
                    onToggleWidgetVisibility = onToggleWidgetVisibility,
                    onMoveWidget = onMoveWidget,
                    onClose = onToggleCustomization
                )
            }

            if (windowInfo.orientation == ScreenOrientationMode.LANDSCAPE) {
                Row(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(windowInfo.contentPadding)
                ) {
                    val gaugeSize = (windowInfo.heightDp * 0.56f).coerceIn(150.dp, 320.dp)
                    SpeedometerCockpitCard(
                        speedKmh = state.currentSpeedKmh,
                        speedStatusNote = state.speedStatusNote,
                        style = state.speedometerStyle,
                        gaugeSize = gaugeSize,
                        modifier = Modifier.weight(0.38f).fillMaxHeight()
                    )

                    LazyVerticalGrid(
                        columns = GridCells.Fixed((windowInfo.gridColumns - 1).coerceAtLeast(1)),
                        modifier = Modifier.weight(0.62f).fillMaxHeight(),
                        verticalArrangement = Arrangement.spacedBy(windowInfo.contentPadding),
                        horizontalArrangement = Arrangement.spacedBy(windowInfo.contentPadding),
                        contentPadding = PaddingValues(bottom = 4.dp)
                    ) {
                        items(activeWidgets, key = { it.name }) { widgetId ->
                            DashboardWidgetCard(
                                widgetId = widgetId,
                                state = state,
                                onIncrementTasbeeh = onIncrementTasbeeh,
                                onOpenSystemSettings = openSystemSetting
                            )
                        }
                    }
                }
            } else {
                Column(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(windowInfo.contentPadding)
                ) {
                    val gaugeSize = (windowInfo.widthDp * 0.52f).coerceIn(170.dp, 300.dp)
                    SpeedometerCockpitCard(
                        speedKmh = state.currentSpeedKmh,
                        speedStatusNote = state.speedStatusNote,
                        style = state.speedometerStyle,
                        gaugeSize = gaugeSize,
                        modifier = Modifier.fillMaxWidth().weight(0.42f)
                    )

                    LazyVerticalGrid(
                        columns = GridCells.Fixed(windowInfo.gridColumns),
                        modifier = Modifier.fillMaxWidth().weight(0.58f),
                        verticalArrangement = Arrangement.spacedBy(windowInfo.contentPadding),
                        horizontalArrangement = Arrangement.spacedBy(windowInfo.contentPadding)
                    ) {
                        items(activeWidgets, key = { it.name }) { widgetId ->
                            DashboardWidgetCard(
                                widgetId = widgetId,
                                state = state,
                                onIncrementTasbeeh = onIncrementTasbeeh,
                                onOpenSystemSettings = openSystemSetting
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CockpitTopStatusBar(
    state: DashboardUiState,
    windowInfo: AutomotiveWindowInfo,
    onRequestLocationPerm: () -> Unit,
    onToggleCustomization: () -> Unit,
    onOpenSystemSetting: (String) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = AutomotiveColors.CockpitCard,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = state.timeFormatted,
                        style = MaterialTheme.typography.headlineLarge,
                        color = AutomotiveColors.TextPrimary,
                        fontWeight = FontWeight.Black
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${state.secondsFormatted} ${state.amPmArabic}",
                        style = MaterialTheme.typography.labelMedium,
                        color = AutomotiveColors.CyberNeonCyan
                    )
                }

                Column {
                    Text(
                        text = "${state.dayNameArabic} • ${state.gregorianDateArabic}",
                        style = MaterialTheme.typography.bodyLarge,
                        color = AutomotiveColors.TextPrimary
                    )
                    Text(
                        text = "${state.hijriDateArabic} • ${windowInfo.profile.arabicLabel}",
                        style = MaterialTheme.typography.labelMedium,
                        color = AutomotiveColors.TextSecondary
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatusIndicatorPill(
                    icon = Icons.Default.GpsFixed,
                    label = state.gpsState.statusLabelAr,
                    tint = when (state.gpsState) {
                        GpsHardwareState.READY_STANDBY -> AutomotiveColors.StatusHealthyGreen
                        GpsHardwareState.DISABLED, GpsHardwareState.PERMISSION_REQUIRED -> AutomotiveColors.SpeedWarningAmber
                        GpsHardwareState.UNSUPPORTED -> AutomotiveColors.AlertCrimson
                    },
                    onClick = {
                        if (state.gpsState == GpsHardwareState.PERMISSION_REQUIRED) {
                            onRequestLocationPerm()
                        } else {
                            onOpenSystemSetting(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                        }
                    }
                )

                StatusIndicatorPill(
                    icon = Icons.Default.Bluetooth,
                    label = state.bluetoothState.statusLabelAr,
                    tint = when (state.bluetoothState) {
                        BluetoothHardwareState.ON_READY -> AutomotiveColors.ElectricBlue
                        BluetoothHardwareState.OFF -> AutomotiveColors.StatusInactiveGray
                        BluetoothHardwareState.UNSUPPORTED -> AutomotiveColors.AlertCrimson
                    },
                    onClick = { onOpenSystemSetting(Settings.ACTION_BLUETOOTH_SETTINGS) }
                )

                StatusIndicatorPill(
                    icon = Icons.Default.Wifi,
                    label = state.networkState.statusLabelAr,
                    tint = if (state.networkState == NetworkConnectionState.OFFLINE) {
                        AutomotiveColors.StatusInactiveGray
                    } else {
                        AutomotiveColors.StatusHealthyGreen
                    },
                    onClick = { onOpenSystemSetting(Settings.ACTION_WIFI_SETTINGS) }
                )

                if (!state.isDefaultLauncher) {
                    StatusIndicatorPill(
                        icon = Icons.Default.Home,
                        label = "تعيين كلانشر",
                        tint = AutomotiveColors.SpeedWarningAmber,
                        onClick = { onOpenSystemSetting(Settings.ACTION_HOME_SETTINGS) }
                    )
                }

                StatusIndicatorPill(
                    icon = Icons.Default.Tune,
                    label = "تخصيص",
                    tint = AutomotiveColors.CyberNeonCyan,
                    onClick = onToggleCustomization
                )
            }
        }
    }
}

@Composable
private fun StatusIndicatorPill(
    icon: ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(50),
        color = AutomotiveColors.CockpitCardElevated,
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(imageVector = icon, contentDescription = label, tint = tint, modifier = Modifier.height(16.dp))
            Text(text = label, style = MaterialTheme.typography.labelMedium, color = AutomotiveColors.TextPrimary)
        }
    }
}
