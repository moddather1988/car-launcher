package com.universal.carlauncher.feature.dashboard.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.universal.carlauncher.core.datastore.SpeedometerStyle
import com.universal.carlauncher.core.theme.AutomotiveColors
import com.universal.carlauncher.core.theme.LocalCockpitThemeConfig
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SpeedometerCockpitCard(
    speedKmh: Int?,
    speedStatusNote: String,
    style: SpeedometerStyle,
    gaugeSize: Dp,
    modifier: Modifier = Modifier
) {
    val themeConfig = LocalCockpitThemeConfig.current
    val displaySpeed = speedKmh ?: 0
    val borderColor = if (themeConfig.neonEnabled) {
        AutomotiveColors.CardBorderNeon.copy(alpha = 0.65f)
    } else {
        AutomotiveColors.CardBorderSubtle
    }

    Card(
        modifier = modifier,
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = AutomotiveColors.CockpitCard),
        border = BorderStroke(if (themeConfig.neonEnabled) 1.5.dp else 1.dp, borderColor)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Surface(
                color = AutomotiveColors.DeepObsidian.copy(alpha = 0.7f),
                shape = RoundedCornerShape(50)
            ) {
                Text(
                    text = if (speedKmh == null) "وضع الانتظار الآمن (REAL GPS)" else "قراءة الأقمار الصناعية المباشرة",
                    style = MaterialTheme.typography.labelMedium,
                    color = if (speedKmh == null) AutomotiveColors.SpeedWarningAmber else AutomotiveColors.CyberNeonCyan,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                )
            }

            Box(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                when (style) {
                    SpeedometerStyle.DIGITAL_ONLY -> {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = displaySpeed.toString(),
                                fontSize = (78 * themeConfig.uiScale).sp,
                                fontWeight = FontWeight.Black,
                                color = AutomotiveColors.TextPrimary
                            )
                            Text(
                                text = "كم / ساعة",
                                style = MaterialTheme.typography.titleMedium,
                                color = AutomotiveColors.ElectricBlue
                            )
                        }
                    }
                    SpeedometerStyle.CIRCULAR_ONLY,
                    SpeedometerStyle.DIGITAL_AND_CIRCULAR -> {
                        CircularAutomotiveGauge(
                            speed = displaySpeed,
                            maxSpeed = 240,
                            showLargeDigitalCenter = (style == SpeedometerStyle.DIGITAL_AND_CIRCULAR),
                            neonEnabled = themeConfig.neonEnabled,
                            size = gaugeSize
                        )
                    }
                }
            }

            Text(
                text = speedStatusNote,
                style = MaterialTheme.typography.labelMedium,
                color = AutomotiveColors.TextSecondary,
                textAlign = TextAlign.Center,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun CircularAutomotiveGauge(
    speed: Int,
    maxSpeed: Int,
    showLargeDigitalCenter: Boolean,
    neonEnabled: Boolean,
    size: Dp
) {
    val scale = LocalCockpitThemeConfig.current.uiScale
    val sweepFraction = (speed.coerceIn(0, maxSpeed).toFloat() / maxSpeed.toFloat())

    Box(
        modifier = Modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize().padding(8.dp)) {
            val strokeWidth = 14.dp.toPx()
            val arcDiameter = minOf(this.size.width, this.size.height) - strokeWidth
            val topLeft = Offset((this.size.width - arcDiameter) / 2f, (this.size.height - arcDiameter) / 2f)
            val arcSize = Size(arcDiameter, arcDiameter)

            drawArc(
                color = Color(0xFF1E293B),
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )

            val activeBrush = Brush.sweepGradient(
                listOf(
                    AutomotiveColors.ElectricBlue,
                    if (neonEnabled) AutomotiveColors.CyberNeonCyan else AutomotiveColors.ElectricBlue,
                    AutomotiveColors.SpeedWarningAmber
                )
            )
            drawArc(
                brush = activeBrush,
                startAngle = 135f,
                sweepAngle = 270f * sweepFraction,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )

            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val outerRadius = arcDiameter / 2f - strokeWidth * 0.9f
            val innerRadius = outerRadius - 8.dp.toPx()

            for (step in 0..12) {
                val angleDeg = 135f + (step * (270f / 12f))
                val angleRad = Math.toRadians(angleDeg.toDouble())
                val startOffset = Offset(
                    x = center.x + (outerRadius * cos(angleRad)).toFloat(),
                    y = center.y + (outerRadius * sin(angleRad)).toFloat()
                )
                val endOffset = Offset(
                    x = center.x + (innerRadius * cos(angleRad)).toFloat(),
                    y = center.y + (innerRadius * sin(angleRad)).toFloat()
                )
                drawLine(
                    color = if (step >= 10) AutomotiveColors.AlertCrimson else AutomotiveColors.TextSecondary,
                    start = startOffset,
                    end = endOffset,
                    strokeWidth = if (step % 2 == 0) 3.dp.toPx() else 1.5.dp.toPx()
                )
            }
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = speed.toString(),
                fontSize = if (showLargeDigitalCenter) (54 * scale).sp else (38 * scale).sp,
                fontWeight = FontWeight.Black,
                color = AutomotiveColors.TextPrimary
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "كم/س",
                style = MaterialTheme.typography.bodyLarge,
                color = if (neonEnabled) AutomotiveColors.CyberNeonCyan else AutomotiveColors.ElectricBlue,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
