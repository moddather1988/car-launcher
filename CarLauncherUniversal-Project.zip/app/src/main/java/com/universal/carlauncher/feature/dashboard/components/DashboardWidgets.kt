package com.universal.carlauncher.feature.dashboard.components

import android.content.Context
import android.provider.Settings
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.universal.carlauncher.core.datastore.DashboardWidgetId
import com.universal.carlauncher.core.datastore.SpeedometerStyle
import com.universal.carlauncher.core.datastore.WidgetSizeScale
import com.universal.carlauncher.core.theme.AutomotiveColors
import com.universal.carlauncher.core.theme.LocalCockpitThemeConfig
import com.universal.carlauncher.feature.dashboard.DashboardUiState
import com.universal.carlauncher.feature.dashboard.InstalledAppShortcut

@Composable
fun DashboardWidgetCard(
    widgetId: DashboardWidgetId,
    state: DashboardUiState,
    onIncrementTasbeeh: () -> Unit,
    onOpenSystemSettings: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val themeConfig = LocalCockpitThemeConfig.current
    val sizeScale = state.widgetSizeScale.scaleMultiplier
    val borderColor = if (themeConfig.neonEnabled) {
        AutomotiveColors.CardBorderNeon.copy(alpha = 0.35f)
    } else {
        AutomotiveColors.CardBorderSubtle
    }

    Card(
        modifier = modifier,
        shape = RoundedCornerShape((16 * sizeScale).dp),
        colors = CardDefaults.cardColors(containerColor = AutomotiveColors.CockpitCard),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding((12 * sizeScale).dp),
            verticalArrangement = Arrangement.spacedBy((6 * sizeScale).dp)
        ) {
            when (widgetId) {
                DashboardWidgetId.COMPASS -> CompassWidgetContent(state)
                DashboardWidgetId.TRIP_SUMMARY -> TripSummaryWidgetContent(state)
                DashboardWidgetId.PRAYER_TIMES -> PrayerWidgetContent(state, onIncrementTasbeeh)
                DashboardWidgetId.WEATHER_TEMP -> WeatherWidgetContent(state)
                DashboardWidgetId.MINI_MUSIC -> MiniMusicWidgetContent(onOpenSystemSettings)
                DashboardWidgetId.APP_SHORTCUTS -> AppShortcutsWidgetContent(
                    shortcuts = state.appShortcuts,
                    onOpenSystemSettings = onOpenSystemSettings
                )
            }
        }
    }
}

@Composable
private fun WidgetHeader(icon: ImageVector, title: String, accentColor: Color = AutomotiveColors.ElectricBlue) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(imageVector = icon, contentDescription = title, tint = accentColor, modifier = Modifier.size(20.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = AutomotiveColors.TextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun CompassWidgetContent(state: DashboardUiState) {
    WidgetHeader(Icons.Default.Explore, "بوصلة الاتجاهات والقبلة")
    val bearingText = state.bearingDegrees?.let { "$it°" } ?: "--° (يتحدث مع حركة السيارة)"
    Text(text = "الاتجاه الحالي: $bearingText", style = MaterialTheme.typography.bodyLarge, color = AutomotiveColors.CyberNeonCyan)
    Text(text = "اتجاه القبلة (القاهرة): 136° جنوب شرق", style = MaterialTheme.typography.labelMedium, color = AutomotiveColors.TextSecondary)
}

@Composable
private fun TripSummaryWidgetContent(state: DashboardUiState) {
    WidgetHeader(Icons.Default.Route, "ملخص الرحلة")
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Column {
            Text("المسافة", style = MaterialTheme.typography.labelMedium, color = AutomotiveColors.TextSecondary)
            Text(state.distanceKmFormatted, style = MaterialTheme.typography.titleMedium, color = AutomotiveColors.TextPrimary)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("أعلى سرعة", style = MaterialTheme.typography.labelMedium, color = AutomotiveColors.TextSecondary)
            Text("${state.maxSpeedKmh} كم/س", style = MaterialTheme.typography.titleMedium, color = AutomotiveColors.SpeedWarningAmber)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text("المدة", style = MaterialTheme.typography.labelMedium, color = AutomotiveColors.TextSecondary)
            Text(state.tripDurationFormatted, style = MaterialTheme.typography.titleMedium, color = AutomotiveColors.CyberNeonCyan)
        }
    }
}

@Composable
private fun PrayerWidgetContent(state: DashboardUiState, onIncrementTasbeeh: () -> Unit) {
    WidgetHeader(Icons.Default.Mosque, "القسم الإسلامي والتقويم", AutomotiveColors.StatusHealthyGreen)
    Text(text = "التاريخ الهجري: ${state.hijriDateArabic}", style = MaterialTheme.typography.bodyLarge, color = AutomotiveColors.TextPrimary)
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("سبحان الله وبحمده", style = MaterialTheme.typography.labelMedium, color = AutomotiveColors.TextSecondary)
        Button(
            onClick = onIncrementTasbeeh,
            colors = ButtonDefaults.buttonColors(containerColor = AutomotiveColors.CockpitCardElevated)
        ) {
            Text("المسبحة: ${state.tasbeehCount}", color = AutomotiveColors.CyberNeonCyan)
        }
    }
}

@Composable
private fun WeatherWidgetContent(state: DashboardUiState) {
    WidgetHeader(Icons.Default.Thermostat, "حساسات السيارة والطقس", AutomotiveColors.SpeedWarningAmber)
    Text(
        text = if (state.hasAmbientTempSensor) "حساس الحرارة المحيطة متاح" else "OBD2 / حرارة خارجية: بانتظار محول ELM327",
        style = MaterialTheme.typography.bodyLarge,
        color = AutomotiveColors.TextPrimary
    )
    Text(text = "النظام يعمل Offline بالكامل بدون بيانات وهمية", style = MaterialTheme.typography.labelMedium, color = AutomotiveColors.TextSecondary)
}

@Composable
private fun MiniMusicWidgetContent(onOpenSystemSettings: (String) -> Unit) {
    WidgetHeader(Icons.Default.MusicNote, "التحكم الصوتي السريع")
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = { onOpenSystemSettings(Settings.ACTION_SOUND_SETTINGS) }) {
            Icon(Icons.Default.SkipPrevious, contentDescription = "السابق", tint = AutomotiveColors.TextPrimary)
        }
        Surface(
            shape = CircleShape,
            color = AutomotiveColors.ElectricBlue,
            modifier = Modifier.size(40.dp).clickable { onOpenSystemSettings(Settings.ACTION_SOUND_SETTINGS) }
        ) {
            Icon(Icons.Default.PlayArrow, contentDescription = "الصوت", tint = AutomotiveColors.DeepObsidian, modifier = Modifier.padding(8.dp))
        }
        IconButton(onClick = { onOpenSystemSettings(Settings.ACTION_SOUND_SETTINGS) }) {
            Icon(Icons.Default.SkipNext, contentDescription = "التالي", tint = AutomotiveColors.TextPrimary)
        }
    }
}

@Composable
private fun AppShortcutsWidgetContent(
    shortcuts: List<InstalledAppShortcut>,
    onOpenSystemSettings: (String) -> Unit
) {
    val context = LocalContext.current
    WidgetHeader(Icons.Default.Apps, "تطبيقات الشاشة السريعة")
    if (shortcuts.isEmpty()) {
        Button(
            onClick = { onOpenSystemSettings(Settings.ACTION_SETTINGS) },
            colors = ButtonDefaults.buttonColors(containerColor = AutomotiveColors.CockpitCardElevated)
        ) {
            Text("فتح إعدادات أندرويد", color = AutomotiveColors.TextPrimary)
        }
    } else {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            items(shortcuts, key = { it.packageName }) { app ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = AutomotiveColors.CockpitCardElevated,
                    border = BorderStroke(1.dp, AutomotiveColors.CardBorderSubtle),
                    modifier = Modifier.clickable { launchPackageSafely(context, app.packageName) }
                ) {
                    Text(
                        text = app.label,
                        style = MaterialTheme.typography.bodyLarge,
                        color = AutomotiveColors.TextPrimary,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        maxLines = 1
                    )
                }
            }
        }
    }
}

private fun launchPackageSafely(context: Context, packageName: String) {
    val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
    if (launchIntent != null) {
        launchIntent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(launchIntent) }
    }
}

@Composable
fun DashboardCustomizationPanel(
    state: DashboardUiState,
    onToggleNeon: (Boolean) -> Unit,
    onSelectSpeedometerStyle: (SpeedometerStyle) -> Unit,
    onSelectWidgetSize: (WidgetSizeScale) -> Unit,
    onToggleWidgetVisibility: (DashboardWidgetId) -> Unit,
    onMoveWidget: (DashboardWidgetId, Boolean) -> Unit,
    onClose: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(8.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = AutomotiveColors.CockpitSurface),
        border = BorderStroke(1.5.dp, AutomotiveColors.ElectricBlue)
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("تخصيص شاشة القيادة", style = MaterialTheme.typography.titleLarge, color = AutomotiveColors.CyberNeonCyan)
                Button(onClick = onClose) { Text("إغلاق") }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("إضاءة Neon:", color = AutomotiveColors.TextPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Switch(checked = state.neonEnabled, onCheckedChange = onToggleNeon)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SpeedometerStyle.entries.forEach { style ->
                        val label = when (style) {
                            SpeedometerStyle.DIGITAL_AND_CIRCULAR -> "مدمج"
                            SpeedometerStyle.DIGITAL_ONLY -> "رقمي"
                            SpeedometerStyle.CIRCULAR_ONLY -> "دائري"
                        }
                        FilterChip(
                            selected = state.speedometerStyle == style,
                            onClick = { onSelectSpeedometerStyle(style) },
                            label = { Text(label) }
                        )
                    }
                }
            }

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(state.orderedWidgets, key = { it.name }) { widgetId ->
                    val isVisible = state.visibleWidgets.contains(widgetId)
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = AutomotiveColors.CockpitCard,
                        border = BorderStroke(1.dp, if (isVisible) AutomotiveColors.ElectricBlue else AutomotiveColors.CardBorderSubtle)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(widgetId.titleAr, color = if (isVisible) AutomotiveColors.TextPrimary else AutomotiveColors.TextMuted)
                            IconButton(onClick = { onToggleWidgetVisibility(widgetId) }) {
                                Icon(
                                    imageVector = if (isVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = null,
                                    tint = if (isVisible) AutomotiveColors.CyberNeonCyan else AutomotiveColors.TextMuted
                                )
                            }
                            IconButton(onClick = { onMoveWidget(widgetId, true) }) {
                                Icon(Icons.Default.ArrowUpward, contentDescription = null, tint = AutomotiveColors.TextPrimary)
                            }
                            IconButton(onClick = { onMoveWidget(widgetId, false) }) {
                                Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = AutomotiveColors.TextPrimary)
                            }
                        }
                    }
                }
            }
        }
    }
}
