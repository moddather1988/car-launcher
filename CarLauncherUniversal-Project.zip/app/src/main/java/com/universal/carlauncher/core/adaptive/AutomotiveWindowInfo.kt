package com.universal.carlauncher.core.adaptive

import android.content.res.Configuration
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.max
import kotlin.math.min

enum class CarScreenProfile(val arabicLabel: String) {
    COMPACT_WVGA("شاشة مدمجة 800×480"),
    STANDARD_WSVGA("شاشة قياسية 1024×600"),
    HD_COCKPIT("شاشة عالية الدقة 1280×720"),
    FULL_HD_COCKPIT("شاشة فائقة الدقة 1920×1080"),
    ULTRAWIDE_COCKPIT("شاشة بانورامية عريضة"),
    PORTRAIT_TESLA("شاشة طولية (نمط تسلا)")
}

enum class ScreenOrientationMode {
    LANDSCAPE,
    PORTRAIT
}

data class AutomotiveWindowInfo(
    val widthDp: Dp,
    val heightDp: Dp,
    val widthPx: Int,
    val heightPx: Int,
    val densityDpi: Int,
    val aspectRatio: Float,
    val orientation: ScreenOrientationMode,
    val profile: CarScreenProfile,
    val uiScaleFactor: Float,
    val gridColumns: Int,
    val contentPadding: Dp
)

object AdaptiveDimensionCalculator {
    fun calculate(
        widthDpValue: Int,
        heightDpValue: Int,
        widthPx: Int,
        heightPx: Int,
        densityDpi: Int,
        isLandscapeConfig: Boolean
    ): AutomotiveWindowInfo {
        val safeWidthDp = max(widthDpValue, 320)
        val safeHeightDp = max(heightDpValue, 240)

        val orientation = if (isLandscapeConfig || safeWidthDp >= safeHeightDp) {
            ScreenOrientationMode.LANDSCAPE
        } else {
            ScreenOrientationMode.PORTRAIT
        }

        val maxPx = max(widthPx, heightPx)
        val minPx = max(min(widthPx, heightPx), 1)
        val aspectRatio = maxPx.toFloat() / minPx.toFloat()

        val profile = when {
            orientation == ScreenOrientationMode.PORTRAIT -> CarScreenProfile.PORTRAIT_TESLA
            aspectRatio >= 2.25f -> CarScreenProfile.ULTRAWIDE_COCKPIT
            maxPx <= 860 && minPx <= 520 -> CarScreenProfile.COMPACT_WVGA
            maxPx <= 1080 && minPx <= 640 -> CarScreenProfile.STANDARD_WSVGA
            maxPx <= 1366 && minPx <= 800 -> CarScreenProfile.HD_COCKPIT
            else -> CarScreenProfile.FULL_HD_COCKPIT
        }

        val shortestDp = min(safeWidthDp, safeHeightDp).toFloat()
        val baseScale = when {
            shortestDp <= 400f -> 0.78f
            shortestDp <= 480f -> 0.88f
            shortestDp <= 600f -> 1.00f
            shortestDp <= 720f -> 1.12f
            else -> 1.22f
        }

        val columns = when (profile) {
            CarScreenProfile.PORTRAIT_TESLA -> 2
            CarScreenProfile.COMPACT_WVGA -> 2
            CarScreenProfile.STANDARD_WSVGA -> 3
            CarScreenProfile.HD_COCKPIT -> 3
            CarScreenProfile.FULL_HD_COCKPIT -> 4
            CarScreenProfile.ULTRAWIDE_COCKPIT -> 4
        }

        val padding = when (profile) {
            CarScreenProfile.COMPACT_WVGA -> 8.dp
            CarScreenProfile.STANDARD_WSVGA -> 10.dp
            else -> 14.dp
        }

        return AutomotiveWindowInfo(
            widthDp = safeWidthDp.dp,
            heightDp = safeHeightDp.dp,
            widthPx = widthPx,
            heightPx = heightPx,
            densityDpi = densityDpi,
            aspectRatio = aspectRatio,
            orientation = orientation,
            profile = profile,
            uiScaleFactor = baseScale,
            gridColumns = columns,
            contentPadding = padding
        )
    }
}

@Composable
fun rememberAutomotiveWindowInfo(): AutomotiveWindowInfo {
    val configuration = LocalConfiguration.current
    val density = LocalDensity.current

    val widthDp = configuration.screenWidthDp
    val heightDp = configuration.screenHeightDp
    val densityDpi = configuration.densityDpi
    val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    val widthPx = with(density) { widthDp.dp.roundToPx() }
    val heightPx = with(density) { heightDp.dp.roundToPx() }

    return remember(widthDp, heightDp, densityDpi, isLandscape) {
        AdaptiveDimensionCalculator.calculate(
            widthDpValue = widthDp,
            heightDpValue = heightDp,
            widthPx = widthPx,
            heightPx = heightPx,
            densityDpi = densityDpi,
            isLandscapeConfig = isLandscape
        )
    }
}
