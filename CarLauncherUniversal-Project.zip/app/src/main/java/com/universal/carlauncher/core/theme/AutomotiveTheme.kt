package com.universal.carlauncher.core.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.sp

data class CockpitThemeConfig(
    val neonEnabled: Boolean = true,
    val uiScale: Float = 1.0f
)

val LocalCockpitThemeConfig = staticCompositionLocalOf { CockpitThemeConfig() }

private val DarkAutomotiveScheme = darkColorScheme(
    primary = AutomotiveColors.ElectricBlue,
    onPrimary = AutomotiveColors.DeepObsidian,
    secondary = AutomotiveColors.CyberNeonCyan,
    onSecondary = AutomotiveColors.DeepObsidian,
    background = AutomotiveColors.DeepObsidian,
    onBackground = AutomotiveColors.TextPrimary,
    surface = AutomotiveColors.CockpitSurface,
    onSurface = AutomotiveColors.TextPrimary,
    surfaceVariant = AutomotiveColors.CockpitCard,
    onSurfaceVariant = AutomotiveColors.TextSecondary,
    error = AutomotiveColors.AlertCrimson
)

@Composable
fun CarLauncherTheme(
    neonEnabled: Boolean = true,
    uiScale: Float = 1.0f,
    content: @Composable () -> Unit
) {
    val scaledTypography = Typography(
        displayLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Black, fontSize = (64 * uiScale).sp),
        headlineLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = (28 * uiScale).sp),
        titleLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = (20 * uiScale).sp),
        titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = (16 * uiScale).sp),
        bodyLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = (14 * uiScale).sp),
        labelMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = (12 * uiScale).sp)
    )

    CompositionLocalProvider(
        LocalLayoutDirection provides LayoutDirection.Rtl,
        LocalCockpitThemeConfig provides CockpitThemeConfig(neonEnabled = neonEnabled, uiScale = uiScale)
    ) {
        MaterialTheme(
            colorScheme = DarkAutomotiveScheme,
            typography = scaledTypography,
            content = content
        )
    }
}
