package com.universal.carlauncher.core.theme

import androidx.compose.ui.graphics.Color

object AutomotiveColors {
    val DeepObsidian = Color(0xFF06080E)
    val CockpitSurface = Color(0xFF0D1322)
    val CockpitCard = Color(0xFF131C31)
    val CockpitCardElevated = Color(0xFF1A2642)

    val ElectricBlue = Color(0xFF00A8E8)
    val CyberNeonCyan = Color(0xFF00F5D4)

    val SpeedWarningAmber = Color(0xFFFFB703)
    val AlertCrimson = Color(0xFFEF233C)
    val StatusHealthyGreen = Color(0xFF10B981)
    val StatusInactiveGray = Color(0xFF64748B)

    val TextPrimary = Color(0xFFF8FAFC)
    val TextSecondary = Color(0xFF94A3B8)
    val TextMuted = Color(0xFF475569)

    val CardBorderSubtle = Color(0xFF1E293B)
    val CardBorderNeon = Color(0xFF00E5FF)
}
