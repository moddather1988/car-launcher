package com.universal.carlauncher

import android.Manifest
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.universal.carlauncher.core.adaptive.rememberAutomotiveWindowInfo
import com.universal.carlauncher.core.theme.CarLauncherTheme
import com.universal.carlauncher.feature.dashboard.DashboardScreen
import com.universal.carlauncher.feature.dashboard.DashboardViewModel

class MainActivity : ComponentActivity() {

    private val dashboardViewModel: DashboardViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableAutomotiveImmersiveMode()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (dashboardViewModel.uiState.value.isCustomizationSheetOpen) {
                    dashboardViewModel.toggleCustomizationSheet()
                }
            }
        })

        setContent {
            val uiState by dashboardViewModel.uiState.collectAsStateWithLifecycle()
            val windowInfo = rememberAutomotiveWindowInfo()

            val locationPermissionLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.RequestMultiplePermissions()
            ) {
                dashboardViewModel.tryRegisterGpsUpdates()
            }

            LaunchedEffect(Unit) {
                locationPermissionLauncher.launch(
                    arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    )
                )
            }

            CarLauncherTheme(
                neonEnabled = uiState.neonEnabled,
                uiScale = windowInfo.uiScaleFactor
            ) {
                DashboardScreen(
                    state = uiState,
                    windowInfo = windowInfo,
                    onRequestLocationPerm = {
                        locationPermissionLauncher.launch(
                            arrayOf(
                                Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION
                            )
                        )
                    },
                    onIncrementTasbeeh = dashboardViewModel::incrementTasbeeh,
                    onToggleCustomization = dashboardViewModel::toggleCustomizationSheet,
                    onToggleNeon = dashboardViewModel::setNeonEnabled,
                    onSelectSpeedometerStyle = dashboardViewModel::setSpeedometerStyle,
                    onSelectWidgetSize = dashboardViewModel::setWidgetSizeScale,
                    onToggleWidgetVisibility = dashboardViewModel::toggleWidgetVisibility,
                    onMoveWidget = dashboardViewModel::moveWidgetOrder
                )
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            enableAutomotiveImmersiveMode()
        }
    }

    private fun enableAutomotiveImmersiveMode() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }
}
