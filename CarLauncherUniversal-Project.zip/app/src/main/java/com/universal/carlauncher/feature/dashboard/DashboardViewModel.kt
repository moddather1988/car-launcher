package com.universal.carlauncher.feature.dashboard

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.universal.carlauncher.core.datastore.DashboardWidgetId
import com.universal.carlauncher.core.datastore.LauncherPreferences
import com.universal.carlauncher.core.datastore.SpeedometerStyle
import com.universal.carlauncher.core.datastore.WidgetSizeScale
import com.universal.carlauncher.core.hardware.GpsHardwareState
import com.universal.carlauncher.core.hardware.LiveHardwareMonitor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.chrono.HijrahDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoField
import java.util.Locale

class DashboardViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = LauncherPreferences(application.applicationContext)
    private val hardwareMonitor = LiveHardwareMonitor(application.applicationContext)
    private val sessionStartElapsedRealtime = SystemClock.elapsedRealtime()

    private val arabicLocale = Locale("ar", "EG")
    private val timeFormatter = DateTimeFormatter.ofPattern("hh:mm", Locale.US)
    private val secondsFormatter = DateTimeFormatter.ofPattern("ss", Locale.US)
    private val dayNameFormatter = DateTimeFormatter.ofPattern("EEEE", arabicLocale)
    private val gregorianFormatter = DateTimeFormatter.ofPattern("dd MMMM yyyy", arabicLocale)

    private val hijriMonthsArabic = arrayOf(
        "محرم", "صفر", "ربيع الأول", "ربيع الآخر",
        "جمادى الأولى", "جمادى الآخرة", "رجب", "شعبان",
        "رمضان", "شوال", "ذو القعدة", "ذو الحجة"
    )

    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    private var lastLocation: Location? = null
    private var accumulatedDistanceKm: Float = 0f
    private var gpsListenerRegistered = false

    private val locationListener = LocationListener { loc ->
        val rawSpeedKmh = if (loc.hasSpeed()) (loc.speed * 3.6f).toInt() else 0
        val heading = if (loc.hasBearing()) loc.bearing.toInt() else null

        lastLocation?.let { prev ->
            val deltaMeters = prev.distanceTo(loc)
            if (deltaMeters > 3.0f && loc.accuracy <= 35f) {
                accumulatedDistanceKm += (deltaMeters / 1000f)
            }
        }
        lastLocation = loc

        _uiState.update { state ->
            val newMax = maxOf(state.maxSpeedKmh, rawSpeedKmh)
            state.copy(
                currentSpeedKmh = rawSpeedKmh,
                maxSpeedKmh = newMax,
                bearingDegrees = heading,
                distanceKmFormatted = String.format(Locale.US, "%.2f كم", accumulatedDistanceKm),
                speedStatusNote = "إشارة GPS نشطة (±${loc.accuracy.toInt()} متر)"
            )
        }
    }

    init {
        observePreferences()
        startRealTimeClockAndHardwareLoop()
        loadInstalledAppShortcuts()
        tryRegisterGpsUpdates()
    }

    @SuppressLint("MissingPermission")
    fun tryRegisterGpsUpdates() {
        val context = getApplication<Application>()
        val snapshot = hardwareMonitor.captureSnapshot()
        if (snapshot.gpsState == GpsHardwareState.READY_STANDBY && !gpsListenerRegistered) {
            val locManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            runCatching {
                locManager?.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    1000L,
                    1f,
                    locationListener
                )
                gpsListenerRegistered = true
            }
        }
    }

    private fun observePreferences() {
        viewModelScope.launch {
            prefs.settingsFlow.collect { saved ->
                _uiState.update { state ->
                    state.copy(
                        neonEnabled = saved.neonAccentEnabled,
                        speedometerStyle = saved.speedometerStyle,
                        widgetSizeScale = saved.widgetSizeScale,
                        visibleWidgets = saved.visibleWidgets,
                        orderedWidgets = saved.widgetOrder
                    )
                }
            }
        }
    }

    private fun startRealTimeClockAndHardwareLoop() {
        viewModelScope.launch {
            var tickCounter = 0
            while (isActive) {
                val now = LocalDateTime.now()
                val hijri = HijrahDate.now()
                val hijriDay = hijri.get(ChronoField.DAY_OF_MONTH)
                val hijriMonthIndex = (hijri.get(ChronoField.MONTH_OF_YEAR) - 1).coerceIn(0, 11)
                val hijriYear = hijri.get(ChronoField.YEAR)
                val hijriText = "$hijriDay ${hijriMonthsArabic[hijriMonthIndex]} $hijriYear هـ"

                val elapsedSec = ((SystemClock.elapsedRealtime() - sessionStartElapsedRealtime) / 1000L)
                    .coerceAtLeast(0L)
                val hours = elapsedSec / 3600
                val minutes = (elapsedSec % 3600) / 60
                val seconds = elapsedSec % 60
                val durationFormatted = String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)

                if (tickCounter % 3 == 0) {
                    val snapshot = hardwareMonitor.captureSnapshot()
                    if (snapshot.gpsState == GpsHardwareState.READY_STANDBY && !gpsListenerRegistered) {
                        tryRegisterGpsUpdates()
                    }
                    val isDefault = checkIsDefaultLauncher()
                    val speedNote = if (_uiState.value.currentSpeedKmh != null) {
                        _uiState.value.speedStatusNote
                    } else {
                        when (snapshot.gpsState) {
                            GpsHardwareState.UNSUPPORTED -> "الشاشة لا تحتوي على مستقبل GPS"
                            GpsHardwareState.PERMISSION_REQUIRED -> "اضغط على أيقونة GPS بالأعلى لمنح الصلاحية"
                            GpsHardwareState.DISABLED -> "يرجى تفعيل الموقع GPS من إعدادات الشاشة"
                            GpsHardwareState.READY_STANDBY -> "GPS متصل - بانتظار التقاط الأقمار الصناعية"
                        }
                    }

                    _uiState.update { current ->
                        current.copy(
                            gpsState = snapshot.gpsState,
                            bluetoothState = snapshot.bluetoothState,
                            networkState = snapshot.networkState,
                            hasAmbientTempSensor = snapshot.hasAmbientTempSensor,
                            hasCompassSensor = snapshot.hasCompassSensor,
                            speedStatusNote = speedNote,
                            isDefaultLauncher = isDefault
                        )
                    }
                }

                _uiState.update { current ->
                    current.copy(
                        timeFormatted = now.format(timeFormatter),
                        secondsFormatted = now.format(secondsFormatter),
                        amPmArabic = if (now.hour < 12) "صباحًا" else "مساءً",
                        dayNameArabic = now.format(dayNameFormatter),
                        gregorianDateArabic = now.format(gregorianFormatter),
                        hijriDateArabic = hijriText,
                        tripDurationFormatted = durationFormatted
                    )
                }

                tickCounter++
                delay(1000L)
            }
        }
    }

    fun loadInstalledAppShortcuts() {
        viewModelScope.launch(Dispatchers.IO) {
            val context = getApplication<Application>()
            val pm = context.packageManager
            val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val resolveInfos = pm.queryIntentActivities(mainIntent, 0)
            val shortcuts = resolveInfos
                .asSequence()
                .filter { it.activityInfo.packageName != context.packageName }
                .take(10)
                .map { info ->
                    InstalledAppShortcut(
                        label = info.loadLabel(pm).toString(),
                        packageName = info.activityInfo.packageName,
                        icon = runCatching { info.loadIcon(pm) }.getOrNull()
                    )
                }
                .toList()

            _uiState.update { it.copy(appShortcuts = shortcuts) }
        }
    }

    private fun checkIsDefaultLauncher(): Boolean {
        val context = getApplication<Application>()
        val intent = Intent(Intent.ACTION_MAIN).apply { addCategory(Intent.CATEGORY_HOME) }
        val resolveInfo = context.packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
        return resolveInfo?.activityInfo?.packageName == context.packageName
    }

    fun incrementTasbeeh() {
        _uiState.update { it.copy(tasbeehCount = it.tasbeehCount + 1) }
    }

    fun toggleCustomizationSheet() {
        _uiState.update { it.copy(isCustomizationSheetOpen = !it.isCustomizationSheetOpen) }
    }

    fun setNeonEnabled(enabled: Boolean) {
        viewModelScope.launch { prefs.setNeonEnabled(enabled) }
    }

    fun setSpeedometerStyle(style: SpeedometerStyle) {
        viewModelScope.launch { prefs.setSpeedometerStyle(style) }
    }

    fun setWidgetSizeScale(scale: WidgetSizeScale) {
        viewModelScope.launch { prefs.setWidgetSizeScale(scale) }
    }

    fun toggleWidgetVisibility(widgetId: DashboardWidgetId) {
        viewModelScope.launch { prefs.toggleWidgetVisibility(widgetId) }
    }

    fun moveWidgetOrder(widgetId: DashboardWidgetId, moveEarlier: Boolean) {
        viewModelScope.launch { prefs.moveWidgetOrder(widgetId, moveEarlier) }
    }

    override fun onCleared() {
        super.onCleared()
        val locManager = getApplication<Application>().getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        runCatching { locManager?.removeUpdates(locationListener) }
    }
}
